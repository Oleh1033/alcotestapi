# Intro 
Branch drugi, czas z prostej implemetacji przejsc do express.

# Wymagana implementacja
Uzyj pliku db/db.txt jako zrodla. Możesz skorzystać z helpera w db.js

Utworzy nastepujace endpointy
GET /api/v1/todos
- by pobrać wszystkie TODO

GET /api/v1/todos/:id
- by pobrać pojedynczy TODO

# Utrudnienia
Ukryte błędy i gotcha
