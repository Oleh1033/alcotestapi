// module.export = function sendMail(user){

// SENDGRID_API_KEY='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';

// const sgMail = require('@sendgrid/mail');
// sgMail.setApiKey(SENDGRID_API_KEY);
// const msg = {
//   to: 'sajmonmajster@gmail.com', //user.emailTo,
//   from: 'test@example.com',
//   subject: user.value,
//   text: '',
//   html: user.message,
// };
// //console.log(user);

// sgMail.send(msg);
// }