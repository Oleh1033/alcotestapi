module.exports = {
    SENDGRID : "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"
}