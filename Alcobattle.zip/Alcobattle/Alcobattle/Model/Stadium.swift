//
//  Stadium.swift
//  Alcobattle
//
//  Created by Oleh on 08/09/2019.
//  Copyright © 2019 Oleh. All rights reserved.
//

import Foundation
import MapKit

struct Stadium {
    var name: String
    var lattitude: CLLocationDegrees
    var longtitude: CLLocationDegrees
}
