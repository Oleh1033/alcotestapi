//
//  GoogleAuth.swift
//  Alcobattle
//
//  Created by Oleh on 06/09/2019.
//  Copyright © 2019 Oleh. All rights reserved.
//

import Foundation
import GoogleSignIn

class GoogleAuth {
    
//    static var shared = GoogleAuth()
//    
//    static let clienId = "792221031150-d8m02baom3mg48u8tv06jmstlqa8skov.apps.googleusercontent.com"
//    
//    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
//        if let error = error {
//            print("\(error.localizedDescription)")
//        } else {
//            let userId = user.userID
//            let idToken = user.authentication.idToken
//            let fullName = user.profile.name
//            let givenName = user.profile.givenName
//            let familyName = user.profile.familyName
//            let email = user.profile.email
//            print(userId!)
//            print(idToken!)
//            print(fullName!)
//            print(fullName!)
//            print(givenName!)
//            print(familyName!)
//            print(email!)
//            
//            Authorization.shared.tokenGoogle = idToken!
//        }
//    }
}
