//
//  Url.swift
//  Alcobattle
//
//  Created by Oleh on 29/08/2019.
//  Copyright © 2019 Oleh. All rights reserved.
//

import Foundation

class ConstantUrl {
    static let baseUrlApi = "https://a238c516.ngrok.io"
}
